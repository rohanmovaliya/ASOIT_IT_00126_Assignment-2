<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    require_once 'PHPExcel/Classes/PHPExcel.php';

    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    // Create a new PHPExcel object
    $objPHPExcel = new PHPExcel();

    // Set the active sheet
    $objPHPExcel->setActiveSheetIndex(0);
    $sheet = $objPHPExcel->getActiveSheet();

    // Set the column headers
    $sheet->setCellValue('A1', 'Name');
    $sheet->setCellValue('B1', 'Email');
    $sheet->setCellValue('C1', 'Phone');
    $sheet->setCellValue('D1', 'Message');

    // Set the data in the respective cells
    $sheet->setCellValue('A2', $name);
    $sheet->setCellValue('B2', $email);
    $sheet->setCellValue('C2', $phone);
    $sheet->setCellValue('D2', $message);

    // Set the file properties
    $objPHPExcel->getProperties()->setCreator('Your Name')
        ->setLastModifiedBy('Your Name')
        ->setTitle('Feedback Data')
        ->setSubject('Feedback Data')
        ->setDescription('Feedback Data');

    // Set the headers for the Excel file download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="feedback_data.xlsx"');
    header('Cache-Control: max-age=0');

    // Save the Excel file to the output stream
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
    exit;
    ?>

</body>

</html>